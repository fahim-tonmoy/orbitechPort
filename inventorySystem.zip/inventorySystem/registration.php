<?php
include 'auth/connection.php';
$conn = connect();

$m = '';
if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $uName = $_POST['uname'];
    $email = $_POST['email'];
    $pass = $_POST['pass'];
    $rPass = $_POST['r_pass'];
    if($pass === $rPass){
        $sq = "INSERT INTO users_info(name, u_name, email, password)".
        "VALUES('$name', '$uName', '$email', '$pass')";
        if($conn->query($sq) === true){
            header('Location: login.php');
        }
        else{
            $m = 'Connection not established!';
        }
    }
    else{
        $m = "password didn't matched!!!";
    }
}
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Registration Form</title>
    <!--    custome Css-->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="./css/register.css">
    <!-- Latest compiled and minified CSS -->
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">


</head>

<body>

    <form method="post" action="registration.php">
        <div class="container">
            <span> <?php if($m != '') echo $m ?></span>
            <h1 class="text-center">Registration Form</h1>
            <hr>
            <div>
                <label> Name<span>*</span> </label>
                <input type="text" name="name" id="name" placeholder="Enter Your Name" required>
            </div>
            <div>
                <label>Username</label>
                <input type="text" name="uname" id="uname" placeholder="Enter Your Username">
            </div>
            <div>
                <label>Email<span>*</span></label>
                <input type="text" name="email" id="email" placeholder="Enter Your Email" required>
            </div>
            <div>
                <label>Password<span>*</span></label>
                <input type="password" name="pass" id="password" placeholder="Enter Your Password" required>
            </div>
            <div>
                <label> Confirm Password<span>*</span></label>
                <input type="password" name="r_pass" id="rpassword" placeholder="Confirm Your Password" required>
            </div>
            <div>
                <p class="text-center"><span>***</span> By creating an account you agree to our <span class="tp">Terms &
                        Privacy</span>. </p>
            </div>
            <div class="text-center">
                <input type="submit" class="btn btn-success" value="Submit" name="submit">
            </div>
            <div class="mt-2">
                <p class="text-center">Already have an account? <a href="login.php"> Sign In</a></p>
            </div>
        </div>
    </form>


    <!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous">
    </script>
</body>

</html>