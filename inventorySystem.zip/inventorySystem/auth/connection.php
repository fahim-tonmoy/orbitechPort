<?php

function connect(){
    $dbhost= "localhost";
    $user= "root";
    $pass= "";
    $dbname= "inventory_project";

    $conn = new mysqli($dbhost, $user, $pass, $dbname);

    return $conn;
}
function closeConnect($cn){
    $cn->close();
}

?>