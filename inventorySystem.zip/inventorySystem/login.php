<?php
include "auth/connection.php";
session_start();
$_SESSION['user']='';
$_SESSION['userid']='';
$conn = connect();

$m = '';
if(isset($_POST['submit'])){
    $uName = $_POST['uname'];
    $pass = $_POST['pass'];

    $sql = "SELECT * FROM users_info WHERE u_name='$uName' and password='$pass'";
    $res = $conn-> query($sql);

    if(mysqli_num_rows($res) == 1){
        $user = mysqli_fetch_assoc($res);
        $id = $user['id'];
        $sq = "UPDATE user_info SET last_login_time = current_timestamp() WHERE id ='$id' ";
        $conn->query($sq);
        $_SESSION['user']= $user['name'];
        $_SESSION['userid']= $user['id'];
        header('Location: dashboard.php');
    }
    else {
        $m = 'Credentials mismathed!!';
    }
}
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Registration Form</title>
    <!--    custome Css-->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="./css/login.css">
    <!-- Latest compiled and minified CSS -->
    <!-- CSS only -->
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous"> -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"
        integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w=="
        crossorigin="anonymous" />


</head>

<body>
    <div class="logo"></div>
    <form method="POST">
        <div class="box bg-img">
            <div class="content">
                <p class="para"> <?php if($m != '') echo $m ?></p>
                <h2>Log <span>In</span></h2>
                <div class="forms">
                    <div class="user-input">
                        <input name="uname" type="text" class="login-input" placeholder="Username" id="name">
                        <i class="fas fa-user"></i>
                    </div>
                    <div class="user-input">
                        <input name="pass" type="password" class="login-input" placeholder="Password" id="my-pass">
                        <span class="eye" onclick="myFunction()">
                            <i id="hide-1" class="fas fa-eye-slash"></i>
                            <i id="hide-2" class="fas fa-eye"></i>
                        </span>
                    </div>
                </div>
                <button class="login-btn" type="submit" name="submit">Sign In</button>
                <p class="new-account"> Not a user? <a href="registration.php">Sign Up now!!</a></p>
                <br>
                <p class="f-pass">
                    <a href="#"> Forgot password?</a>
                </p>
            </div>
        </div>
    </form>


    <!-- JavaScript Bundle with Popper -->
    <script>
    function myFunction() {
        const x = doccument.getElementById("my-pass");
        const y = doccument.getElementById("hide-1");
        const z = doccument.getElementById("hide-2");

        if (x.type === "password") {
            x.type = "text";
            y.style.display = "block";
            z.style.display = "none";
        } else {
            x.type = "password";
            y.style.display = "none";
            z.style.display = "block";
        }
    }
    </script>
</body>

</html>